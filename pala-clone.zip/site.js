(function(){
'use strict';

const NAV=[
  ['launch','Launchpad','launch.html'],['create','Create','create.html'],['trade','Trade','trade.html'],
  ['stoke','Token','stoke.html'],['dashboard','Portfolio','dashboard.html'],
  ['economics','Economics','economics.html'],['docs','Docs','docs.html']
];

/* ---------- toast ---------- */
let toastEl, toastTimer;
function toast(msg){
  if(!toastEl){toastEl=document.createElement('div');toastEl.id='toast';toastEl.setAttribute('role','status');document.body.appendChild(toastEl)}
  toastEl.textContent=msg;toastEl.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove('show'),2200);
}
window.toast=toast;
document.addEventListener('click',e=>{const b=e.target.closest('[data-toast]');if(b){e.preventDefault();toast(b.dataset.toast)}});

/* ---------- chrome ---------- */
function chrome(){
  const page=document.body.dataset.page||'';
  const top=document.createElement('div');
  top.innerHTML=`
  <div class="net"><i></i> Elysium Testnet (99801) · Demo clone with mock data, not the official site</div>
  <header>
    <a class="logo" href="index.html">PALA<span>.</span></a>
    <nav aria-label="Main">${NAV.map(n=>`<a href="${n[2]}" class="${n[0]===page?'on':''}">${n[1]}</a>`).join('')}</nav>
    <div class="hright">
      <button class="chip" data-toast="Demo only: network switching is unavailable.">Elysium/…</button>
      <a class="chip" href="#" data-toast="Demo only: this faucet link is not real.">Faucet</a>
      <button class="btn" data-toast="Demo only: wallet is not connected.">Sign in</button>
    </div>
  </header>`;
  const frag=document.createDocumentFragment();
  while(top.firstChild)frag.appendChild(top.firstChild);
  document.body.prepend(frag);

  const ft=document.createElement('footer');
  ft.innerHTML=`
  <div>
    <div class="logo" style="color:var(--text)">PALA<span>.</span></div>
    <p style="margin-top:8px;max-width:340px">A unified path from token launch to institutional liquidity. Bonding curves, HyperCore spot, and HIP-3 perpetuals in one L1 terminal.</p>
    <p style="margin-top:8px">Built on Elysium · settles to HyperEVM</p>
  </div>
  <div><h4>Platform</h4><ul><li><a href="launch.html">Launchpad</a></li><li><a href="create.html">Create a token</a></li><li><a href="trade.html">Trade &amp; Swap</a></li><li><a href="stoke.html">STOKE token</a></li><li><a href="economics.html">Economics</a></li></ul></div>
  <div><h4>Resources</h4><ul><li><a href="dashboard.html">Portfolio</a></li><li><a href="docs.html">Documentation</a></li><li><a href="docs.html#payments">Payments</a></li><li><a href="docs.html#mainnet">Mainnet checklist</a></li><li><a href="docs.html#network">About &amp; architecture</a></li></ul></div>
  <div><h4>Network</h4><ul><li>Elysium · Chain 99801</li><li>Native gas · HYPE</li><li><a href="#" data-toast="Demo only: external link is disabled.">Explorer ↗</a></li><li><a href="#" data-toast="Demo only: external link is disabled.">Liquidity portal ↗</a></li></ul></div>
  <div class="copy">© 2026 PALA (demo clone for learning). HyperCore L1 &amp; HyperEVM · Non-custodial markets</div>`;
  document.body.appendChild(ft);
}

/* ---------- shared data & helpers ---------- */
const HYPE_USD=24.78, OPEN=3.529e-10, SUPPLY=1e9, RATIO=14.7;
const fmtN=(n,d=2)=>n.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const SUB='₀₁₂₃₄₅₆₇₈₉';
function priceStr(p){
  if(p>=0.001)return fmtN(p,6);
  const z=Math.floor(-Math.log10(p));
  const dg=Math.round(p*Math.pow(10,z+1)*1000).toString().slice(0,4);
  return '0.0'+String(z).split('').map(d=>SUB[+d]).join('')+dg;
}
const SECTORS={infra:'Infra',ai:'AI',rwa:'RWA',meme:'Meme',gaming:'Gaming',dao:'DAO'};
const STATUS={curve:'Live curve',ready:'Ready to graduate',pool:'Pool live',perp:'Perp live'};
const DEFS=[
  ['Volta Labs','VOLTA','infra',62,'curve',18.4,0.84],
  ['Nimbus AI','NIMBUS','ai',91,'curve',42.1,2.31],
  ['Orbit RWA','ORBR','rwa',98,'ready',6.2,1.02],
  ['Pepe Elysium','PEPEY','meme',34,'curve',-7.8,0.41],
  ['Kinetic Quest','KQST','gaming',100,'pool',11.9,3.77],
  ['Halo DAO','HALO','dao',100,'perp',3.4,5.12],
  ['Sable','SABLE','infra',12,'curve',1.2,0.09],
  ['Glacier','GLCR','ai',100,'pool',-2.1,2.05],
  ['Moonwell Mints','MWM','meme',71,'curve',25.6,1.48],
  ['Atlas Bonds','ATLAS','rwa',100,'perp',0.8,4.4]
];
const LAUNCHES=DEFS.map((d,i)=>{
  const price=OPEN*(1+d[3]/100*(RATIO-1));
  return {name:d[0],tick:d[1],sector:d[2],prog:d[3],status:d[4],chg:d[5],vol:d[6],price,mcap:price*SUPPLY*HYPE_USD,age:i};
});
const hue=s=>[...s].reduce((a,c)=>a*31+c.charCodeAt(0)|0,5)%360;
const avatar=t=>`<span class="tav" style="background:hsl(${hue(t.tick)} 45% 24%)">${t.tick[0]}</span>`;
const chg=c=>`<span class="${c>=0?'up':'down'} mono">${c>=0?'+':''}${c.toFixed(2)}%</span>`;
function rowsHTML(list){
  if(!list.length)return '<tr><td colspan="5" class="empty">No launches match this filter.</td></tr>';
  return list.map(t=>`<tr>
    <td><div class="tcell">${avatar(t)}<div><b>${t.name}</b><small>$${t.tick} · ${SECTORS[t.sector]}</small></div></div></td>
    <td class="mono">${priceStr(t.price)}</td>
    <td class="mono">$${fmtN(t.mcap)}</td>
    <td>${chg(t.chg)}</td>
    <td><div class="pcell"><div class="prog" role="progressbar" aria-valuenow="${t.prog}" aria-valuemin="0" aria-valuemax="100"><i style="width:${t.prog}%"></i></div><span class="mono">${t.prog}%</span><span class="st ${t.status}">${STATUS[t.status]}</span></div></td>
  </tr>`).join('');
}
function cardsHTML(list){
  if(!list.length)return '<div class="empty">No launches match this filter.</div>';
  return list.map(t=>`<div class="lcard">
    <div class="top"><div class="tcell">${avatar(t)}<div><b>${t.name}</b><small>$${t.tick} · ${SECTORS[t.sector]}</small></div></div><span class="st ${t.status}">${STATUS[t.status]}</span></div>
    <div class="meta"><span>Price (HYPE)</span><b class="mono">${priceStr(t.price)}</b></div>
    <div class="meta"><span>Market cap</span><b class="mono">$${fmtN(t.mcap)}</b></div>
    <div class="meta"><span>24h</span>${chg(t.chg)}</div>
    <div class="pcell" style="min-width:0"><div class="prog"><i style="width:${t.prog}%"></i></div><span class="mono">${t.prog}%</span></div>
  </div>`).join('');
}

window.PALA={HYPE_USD,OPEN,SUPPLY,RATIO,fmtN,priceStr,SECTORS,STATUS,LAUNCHES,rowsHTML,cardsHTML,avatar,chg};
chrome();
})();
